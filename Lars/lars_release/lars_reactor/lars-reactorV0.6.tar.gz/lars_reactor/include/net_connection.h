#pragma once

/*
 *
 * 抽象的链接类 
 *
 * */
class net_connection 
{
public:
    net_connection() {}

    //纯虚函数 
    virtual int send_message(const char *data, int msglen, int msgid) = 0;
};


