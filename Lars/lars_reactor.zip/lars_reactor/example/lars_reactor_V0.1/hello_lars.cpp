#include "lars_reactor.h"


int main()
{
    lars_hello();

    return 0;
}
