#!/bin/bash

#proto编译
protoc --cpp_out=. ./*.proto
